package com.educademy.controller.services;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.educademy.model.dao.Fetchnamedao;

public class Fetchname {

	public ResultSet fetchname(String email) throws SQLException {
		Fetchnamedao d=new Fetchnamedao();
		ResultSet a=d.select(email);
		return a;
 	}

}
