package com.educademy.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import com.educademy.controller.services.EditUserService;

import com.educademy.model.bean.UpdateBean;

/**
 * Servlet implementation class EditUserController
 */
@WebServlet("/EditUserController")
public class EditUserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		HttpSession session = request.getSession(false);
		String age = request.getParameter("age");
		int age1=Integer.parseInt(age);
		String contact = request.getParameter("contact");
		String role = request.getParameter("role");
		int role1=Integer.parseInt(role);
		
		PrintWriter out = response.getWriter();
		System.out.println(age);
		String id=(String)session.getAttribute("user_ID");
		try {
			EditUserService a=new EditUserService();
			UpdateBean b = new UpdateBean(id,age1,contact,role1);
			String output =a.updateService(b);
			if (output.equals("updated")) {
				
				response.setContentType("text/html");
				out.print("Agent Profile Updation Successful!!");
				javax.servlet.RequestDispatcher rd = request.getRequestDispatcher("user.jsp");
				rd.include(request, response);
				
			} else {
				out.print("Agent Profile Updation Unsuccessful!!");
				javax.servlet.RequestDispatcher rd = request.getRequestDispatcher("user.jsp");
				rd.include(request, response);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		}
	}


	


