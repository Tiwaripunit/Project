package com.educademy.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.educademy.controller.services.SampleLoginRegister;
import com.educademy.model.bean.AddressLoginBean;
import com.educademy.model.bean.SampleLoginBean;

/**
 * Servlet implementation class SampleLoginController
 */
@WebServlet("/SampleLoginController")
public class SampleLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String name=request.getParameter("name");
		int age=Integer.parseInt(request.getParameter("age"));
		String gender=request.getParameter("gender");
		String contact_Number=request.getParameter("Contact");
		String address=request.getParameter("add");
		String address2=request.getParameter("addl2");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String country=request.getParameter("country");
		String pincode=request.getParameter("pincode");
		String pass=request.getParameter("pass");
		int role=Integer.parseInt(request.getParameter("role"));
		int add=1;
		
		SampleLoginRegister sr=new SampleLoginRegister();
		String user_ID=sr.generateId();
		
		AddressLoginBean ab=new AddressLoginBean(address,address2,city,state,country,pincode);
		SampleLoginBean sb=new SampleLoginBean(user_ID, name, age, gender, contact_Number, add, pass, role);
		
		PrintWriter out = response.getWriter();
		try {
			int output1=sr.authenticateAddress(ab);
			String output =sr.authenticateService(sb);
			if (output.equals("success")&& output1==1) {
				response.setContentType("text/html");
				out.print("Registration Successful!!");
				RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
				rd.include(request, response);
			} else {
				out.print("Registration Unsuccessful!!");
				RequestDispatcher rd = request.getRequestDispatcher("view/admin_reg.jsp");
				rd.include(request, response);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
