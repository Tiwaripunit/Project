package com.educademy.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Confirm
 */
@WebServlet("/Confirm")
public class Confirm extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public static int f=0;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession se=request.getSession(false);
		se.setAttribute("data", "ana");
		PrintWriter out=response.getWriter();
		f=1;
		out.println("<script>");
		out.println("alert('Your purchase is successful')");
		out.println("</script>");
		RequestDispatcher rd = request.getRequestDispatcher("bill.jsp");
		rd.include(request, response);
		
		
	}

}
