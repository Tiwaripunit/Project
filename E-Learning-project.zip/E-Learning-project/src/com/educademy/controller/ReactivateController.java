package com.educademy.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.educademy.model.dao.ReactivateDao;

/**
 * Servlet implementation class ReactivateController
 */
@WebServlet("/ReactivateController")
public class ReactivateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String uid=request.getParameter("email");
		try {
			int s=ReactivateDao.update(uid);
			System.out.println("SsS : "+s);
			if(s==1)
			{
				out.println("<script>");
				out.println("alert('Account Reactivated Successfully!!!!')");
				out.println("</script>");
				
				RequestDispatcher rd = request.getRequestDispatcher("reactivateuser.html");
				rd.include(request, response);
				
			}
			else
			{
				out.println("Error");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
