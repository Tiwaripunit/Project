package com.educademy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//import com.educademy.model.bean.UpdateBean;
import com.educademy.model.bean.UpdateStatusBean;
import com.educademy.model.dao.util.DBConnection;

public class  ReactivateDao{
	
	public static int f=0;
	
	public static int update(String em)throws Exception
	{
	Connection conn=DBConnection.getConnect();
	PreparedStatement stmt=conn.prepareStatement("update user set status=0 where user_ID="+'"' + em + '"'); 
	//stmt.setInt(1,b.getAge());
	//stmt.setString(2,b.getContact_Number() );
	//stmt.setInt(3,b.getRole());
	//System.out.println(stmt);
	//stmt.setString(2,b.getId());
	f=1;
	System.out.println("REac  "+stmt);
	//System.out.println(st);
	int status=stmt.executeUpdate();  
	return status;
}

}
