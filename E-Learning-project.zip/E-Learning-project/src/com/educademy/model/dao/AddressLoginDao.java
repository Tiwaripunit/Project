package com.educademy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.educademy.model.bean.AddressLoginBean;
import com.educademy.model.dao.util.DBConnection;

public class AddressLoginDao 
{
	public int insert(AddressLoginBean sb) {
		int message = 0;
		Connection conn = DBConnection.getConnect();
		
		try {
			PreparedStatement ps = conn.prepareStatement
					("insert into address1 (address_ID,Address_Line1,Address_Line2,City,State,Country,Pin_Code) values(?,?,?,?,?,?)");
            ps.setString(1, sb.getAddress());
            ps.setString(2, sb.getAddress2());
            ps.setString(3, sb.getCity());
            ps.setString(4, sb.getState());
            ps.setString(5, sb.getCountry());
            ps.setString(6, sb.getPincode());
            
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return message;
	}
}
