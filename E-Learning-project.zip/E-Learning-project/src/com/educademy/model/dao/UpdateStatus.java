package com.educademy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//import com.educademy.model.bean.UpdateBean;
import com.educademy.model.bean.UpdateStatusBean;
import com.educademy.model.dao.util.DBConnection;

public class UpdateStatus {
	public static int st=0;
	public static int update(UpdateStatusBean b)throws Exception
	{
		ResultSet rs=null;
	Connection conn=DBConnection.getConnect();
	PreparedStatement stmt=conn.prepareStatement("update user set status=1 where user_ID="+'"' + b.getId() + '"');
	PreparedStatement stmt1=conn.prepareStatement("select status from user where user_ID="+'"' + b.getId() + '"'); 
	//stmt.setInt(1,b.getAge());
	//stmt.setString(2,b.getContact_Number() );
	//stmt.setInt(3,b.getRole());
	//System.out.println(stmt);
	//stmt.setString(2,b.getId());
	rs=stmt1.executeQuery();
	rs.next();
	st=rs.getInt("status");
	//System.out.println(st);
	int status=stmt.executeUpdate();  
	return status;
}

}
