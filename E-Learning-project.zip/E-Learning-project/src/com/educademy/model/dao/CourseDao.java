package com.educademy.model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.educademy.model.bean.CourseBean;
import com.educademy.model.dao.util.DBConnection;

public class CourseDao {

	public List<CourseBean> select1() throws SQLException {
		Connection conn=DBConnection.getConnect();
		Statement st=conn.createStatement();
		String query="";
		
			
	
			query="select * from course ";
			System.out.println(query);
		ResultSet rs=st.executeQuery(query);
		List<CourseBean> medicare=new ArrayList<>();
		while(rs.next())
		{
		
			CourseBean b=new CourseBean(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
			medicare.add(b);
			
		}	
		return (ArrayList<CourseBean>) medicare;
	}
	
	public List<CourseBean> select1(String a) throws SQLException {
		Connection conn=DBConnection.getConnect();
		Statement st=conn.createStatement();
		String query="";
		
			
	
			query="select * from course where course_ID='"+a+"'";
			System.out.println(query);
		ResultSet rs=st.executeQuery(query);
		List<CourseBean> medicare=new ArrayList<>();
		while(rs.next())
		{
		
			CourseBean b=new CourseBean(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
			medicare.add(b);
			
		}	
		return (ArrayList<CourseBean>) medicare;
	}

}
