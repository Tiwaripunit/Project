package com.educademy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.educademy.model.bean.SampleLoginBean;
import com.educademy.model.dao.util.DBConnection;

public class SampleLoginDao {

	/*
	 * @Override public boolean insertStudentDetails(StudentBean student) {
	 * boolean flag=false;
	 * 
	 * Connection conn=DBUtil.getConnect(); try { PreparedStatement
	 * ps=conn.prepareStatement("insert into student values (?,?,?)");
	 * ps.setInt(1, student.getRoll()); ps.setString(2, student.getName());
	 * ps.setInt(3, student.getMarks()); int x=ps.executeUpdate(); if(x>0) {
	 * flag=true; System.out.println("record inserted"); } else
	 * System.out.println("failed"); } catch (SQLException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } return flag; }
	 */

	public int insert(SampleLoginBean sb) {
		int message = 0;
		Connection conn = DBConnection.getConnect();
		
		try {
			PreparedStatement ps = conn.prepareStatement("insert into user value(?,?,?,?,?,?,?,?)");
            ps.setString(1, sb.getUser_ID());
            ps.setString(2, sb.getName());
            ps.setInt(3, sb.getAge());
            ps.setString(4, sb.getGender());
            ps.setString(5, sb.getContact_Number());
            ps.setInt(6, sb.getAddress());
            ps.setString(7, sb.getPassword());
            ps.setInt(8, sb.getRole());
            
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return message;
	}

}
