package com.educademy.model.dao.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private static Connection conn = null;

	public static Connection getConnect() {
		if (conn == null) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {

				e.printStackTrace();
			}
			String cs = "jdbc:mysql://localhost:3306/elearning";
			try {
				conn = DriverManager.getConnection(cs, "root", "root");
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
		return conn;
	}
}
