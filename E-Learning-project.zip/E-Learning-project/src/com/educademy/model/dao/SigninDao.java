package com.educademy.model.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.educademy.model.bean.SigninBean;
import com.educademy.model.dao.util.DBConnection;

public class SigninDao 
{
	public ResultSet insert(SigninBean sb)
	{
		Connection conn=DBConnection.getConnect();
		ResultSet rs=null;
		try {
			PreparedStatement ps=conn.prepareStatement("select user_ID, Password, Role from user where user_ID=?;");
			ps.setString(1, sb.getUname());
			
			rs=ps.executeQuery();
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return rs;
	}
}
