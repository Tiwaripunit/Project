package com.educademy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.educademy.model.bean.UpdateBean;
import com.educademy.model.dao.util.DBConnection;

public class UpdateDAO {
	public int update(UpdateBean b)throws Exception
	{
	Connection conn=DBConnection.getConnect();
	PreparedStatement stmt=conn.prepareStatement("update user set Age=?,Contact_Number=?,Role=? where user_ID=?");  
	stmt.setInt(1,b.getAge());
	stmt.setString(2,b.getContact_Number() );
	stmt.setInt(3,b.getRole());

	stmt.setString(4,b.getUser_ID());
	
	int status=stmt.executeUpdate();  
	return status;
}

}
