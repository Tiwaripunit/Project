package com.educademy.model.bean;

public class UpdateBean {
	private String user_ID;
	private int Age;
	private String Contact_Number;

	private int Role;
	
	
	

	public UpdateBean(String user_ID, int age, String contact_Number,  int role) {
		super();
		this.user_ID = user_ID;
		Age = age;
		Contact_Number = contact_Number;
		
		Role = role;
	}

	public String getUser_ID() {
		return user_ID;
	}

	public void setUser_ID(String user_ID) {
		this.user_ID = user_ID;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}

	public String getContact_Number() {
		return Contact_Number;
	}

	public void setContact_Number(String contact_Number) {
		Contact_Number = contact_Number;
	}

	

	public int getRole() {
		return Role;
	}

	public void setRole(int role) {
		Role = role;
	}

	
}
