package com.educademy.model.bean;

public class UpdateStatusBean {

	
public UpdateStatusBean(String id) {
		super();
		this.id = id;
	}

private	String id;

public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}
}
